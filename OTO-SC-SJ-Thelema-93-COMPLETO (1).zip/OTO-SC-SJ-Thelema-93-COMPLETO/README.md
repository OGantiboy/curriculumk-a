# O.T.O. SC-SJ · Thelema-93! — Portal Completo

Versão consolidada e revisada do portal.

## Publicação
O site é autocontido: basta publicar `index.html`.

### GitHub Pages
1. Crie/abra o repositório.
2. Envie `index.html` para a raiz.
3. Abra Settings → Pages.
4. Selecione Deploy from a branch → main → /root.

### Netlify
Arraste a pasta ou este ZIP para um novo deploy.

## Abas incluídas
1. Início
2. Ferramentas
3. Cartas
4. Golden Dawn Tarot
5. Biblioteca
6. Sigilos
7. Correspondências
8. Oráculo
9. Caderno
10. Imagens
11. Acervo 1972
12. A∴A∴
13. Manifesto
14. Sobre

## Funcionalidades
- Tarot completo de 78 cartas, 1/3/5 cartas e reversões.
- Golden Dawn Tarot com 6 referências visuais fornecidas no projeto.
- Correspondências dos 22 Arcanos Maiores.
- Busca no núcleo Golden Dawn e na Biblioteca.
- Gerador de sigilos com exportação PNG.
- Correspondências planetárias/elementais.
- Oráculo e dado d20.
- Caderno local com salvar/limpar/exportar TXT.
- Gematria alfabética simples A=1…Z=26.
- Temporizador de prática.
- Galeria/modal.
- Acervo 1972 preservado.
- Guia A∴A∴ preservado.
- Funciona sem frameworks, fontes remotas, cookies ou trackers.

## Nota editorial
Projeto independente de estudo. O nome do portal não constitui declaração de
charter, reconhecimento ou representação oficial de O.T.O., A∴A∴,
Hermetic Order of the Golden Dawn ou organizações contemporâneas com nomes
semelhantes.
