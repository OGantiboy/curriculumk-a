# Revisão consolidada — 08/09/2026

- Restauradas as áreas do portal anterior que haviam ficado fora da versão reduzida.
- Preservados: Sigilos, Correspondências, Oráculo, Caderno, Imagens, Acervo 1972,
  A∴A∴ e Manifesto.
- Criada aba própria “Golden Dawn Tarot”.
- Incorporadas as 6 novas fotografias do deck.
- Corrigida a sequência do deck documentado para VIII — A Força e XI — A Justiça.
- Corrigido “Ouross” para “Pentáculos”.
- Cortes alinhadas ao material fotografado: Princesa, Príncipe, Rainha e Rei.
- “O Mundo” ajustado para “O Universo” no catálogo deste esquema.
- Adicionado Golden Dawn Tarot à Biblioteca pesquisável.
- Adicionados gematria simples e temporizador.
- Adicionada exportação PNG ao Sigil Engine.
- Adicionada exportação TXT ao Caderno.
- Adicionadas notas editoriais para separar fonte, interpretação e experiência.
- Navegação reorganizada em 14 abas.
